/** This file is used to import the data types that this plugin provides */
export interface image_display
{
	 // functions that your plugin exports
}
