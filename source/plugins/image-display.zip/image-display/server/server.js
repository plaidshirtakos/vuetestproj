export function setup(options, imports, register) {
    let image_display = {};
    register(null, {
        image_display
    });
}
